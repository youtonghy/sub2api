variable "hobby" {
  type = string
}