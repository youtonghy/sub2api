//
//
// File generated from our OpenAPI spec
//
//

package stripe

// The type of parent that generated this invoice item
type InvoiceItemParentType string

// List of values that InvoiceItemParentType can take
const (
	InvoiceItemParentTypeSubscriptionDetails InvoiceItemParentType = "subscription_details"
)

// The type of the pricing details.
type InvoiceItemPricingType string

// List of values that InvoiceItemPricingType can take
const (
	InvoiceItemPricingTypePriceDetails InvoiceItemPricingType = "price_details"
)

// Deletes an invoice item, removing it from an invoice. Deleting invoice items is only possible when they're not attached to invoices, or if it's attached to a draft invoice.
type InvoiceItemParams struct {
	Params `form:"*"`
	// The integer amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. If you want to apply a credit to the customer's account, pass a negative amount.
	Amount *int64 `form:"amount" json:"amount,omitempty"`
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency *string `form:"currency" json:"currency,omitempty"`
	// The ID of the customer to bill for this invoice item.
	Customer *string `form:"customer" json:"customer,omitempty"`
	// The ID of the account representing the customer to bill for this invoice item.
	CustomerAccount *string `form:"customer_account" json:"customer_account,omitempty"`
	// An arbitrary string which you can attach to the invoice item. The description is displayed in the invoice for easy tracking.
	Description *string `form:"description" json:"description,omitempty"`
	// Controls whether discounts apply to this invoice item. Defaults to false for prorations or negative invoice items, and true for all other invoice items. Cannot be set to true for prorations.
	Discountable *bool `form:"discountable" json:"discountable,omitempty"`
	// The coupons, promotion codes & existing discounts which apply to the invoice item or invoice line item. Item discounts are applied before invoice discounts. Pass an empty string to remove previously-defined discounts.
	Discounts []*InvoiceItemDiscountParams `form:"discounts" json:"discounts,omitempty"`
	// Specifies which fields in the response should be expanded.
	Expand []*string `form:"expand" json:"expand,omitempty"`
	// The ID of an existing invoice to add this invoice item to. For subscription invoices, when left blank, the invoice item will be added to the next upcoming scheduled invoice. For standalone invoices, the invoice item won't be automatically added unless you pass `pending_invoice_item_behavior: 'include'` when creating the invoice. This is useful when adding invoice items in response to an invoice.created webhook. You can only add invoice items to draft invoices and there is a maximum of 250 items per invoice.
	Invoice *string `form:"invoice" json:"invoice,omitempty"`
	// Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
	Metadata map[string]string `form:"metadata" json:"metadata,omitempty"`
	// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
	Period *InvoiceItemPeriodParams `form:"period" json:"period,omitempty"`
	// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
	PriceData *InvoiceItemPriceDataParams `form:"price_data" json:"price_data,omitempty"`
	// The pricing information for the invoice item.
	Pricing *InvoiceItemPricingParams `form:"pricing" json:"pricing,omitempty"`
	// Non-negative integer. The quantity of units for the invoice item. Use `quantity_decimal` instead to provide decimal precision. This field will be deprecated in favor of `quantity_decimal` in a future version.
	Quantity *int64 `form:"quantity" json:"quantity,omitempty"`
	// Non-negative decimal with at most 12 decimal places. The quantity of units for the invoice item.
	QuantityDecimal *float64 `form:"quantity_decimal,high_precision" json:"quantity_decimal,string,omitempty"`
	// The ID of a subscription to add this invoice item to. When left blank, the invoice item is added to the next upcoming scheduled invoice. When set, scheduled invoices for subscriptions other than the specified subscription will ignore the invoice item. Use this when you want to express that an invoice item has been accrued within the context of a particular subscription.
	Subscription *string `form:"subscription" json:"subscription,omitempty"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
	TaxCode *string `form:"tax_code" json:"tax_code,omitempty"`
	// The tax rates which apply to the invoice item. When set, the `default_tax_rates` on the invoice do not apply to this invoice item. Pass an empty string to remove previously-defined tax rates.
	TaxRates []*string `form:"tax_rates" json:"tax_rates,omitempty"`
	// The decimal unit amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. This `unit_amount_decimal` will be multiplied by the quantity to get the full amount. Passing in a negative `unit_amount_decimal` will reduce the `amount_due` on the invoice. Accepts at most 12 decimal places.
	UnitAmountDecimal *float64                      `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
	UnsetFields       []InvoiceItemParamsUnsetField `form:"-" json:"-"`
}

// InvoiceItemParamsUnsetField is the list of fields that can be cleared/unset on InvoiceItemParams.
type InvoiceItemParamsUnsetField string

const (
	InvoiceItemParamsUnsetFieldDiscounts InvoiceItemParamsUnsetField = "discounts"
	InvoiceItemParamsUnsetFieldMetadata  InvoiceItemParamsUnsetField = "metadata"
	InvoiceItemParamsUnsetFieldTaxCode   InvoiceItemParamsUnsetField = "tax_code"
	InvoiceItemParamsUnsetFieldTaxRates  InvoiceItemParamsUnsetField = "tax_rates"
)

// AddUnsetField adds a field to the list of fields to clear/unset on this params object.
func (p *InvoiceItemParams) AddUnsetField(field InvoiceItemParamsUnsetField) {
	p.UnsetFields = append(p.UnsetFields, field)
}

// AddExpand appends a new field to expand.
func (p *InvoiceItemParams) AddExpand(f string) {
	p.Expand = append(p.Expand, &f)
}

// AddMetadata adds a new key-value pair to the Metadata.
func (p *InvoiceItemParams) AddMetadata(key string, value string) {
	if p.Metadata == nil {
		p.Metadata = make(map[string]string)
	}

	p.Metadata[key] = value
}

// The coupons, promotion codes & existing discounts which apply to the invoice item or invoice line item. Item discounts are applied before invoice discounts. Pass an empty string to remove previously-defined discounts.
type InvoiceItemDiscountParams struct {
	// ID of the coupon to create a new discount for.
	Coupon *string `form:"coupon" json:"coupon,omitempty"`
	// ID of an existing discount on the object (or one of its ancestors) to reuse.
	Discount *string `form:"discount" json:"discount,omitempty"`
	// ID of the promotion code to create a new discount for.
	PromotionCode *string `form:"promotion_code" json:"promotion_code,omitempty"`
}

// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
type InvoiceItemPeriodParams struct {
	// The end of the period, which must be greater than or equal to the start. This value is inclusive.
	End *int64 `form:"end" json:"end"`
	// The start of the period. This value is inclusive.
	Start *int64 `form:"start" json:"start"`
}

// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
type InvoiceItemPriceDataParams struct {
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency *string `form:"currency" json:"currency"`
	// The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
	Product *string `form:"product" json:"product"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
	UnitAmount *int64 `form:"unit_amount" json:"unit_amount,omitempty"`
	// Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
	UnitAmountDecimal *float64 `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
}

// The pricing information for the invoice item.
type InvoiceItemPricingParams struct {
	// The ID of the price object.
	Price *string `form:"price" json:"price,omitempty"`
}

// Returns a list of your invoice items. Invoice items are returned sorted by creation date, with the most recently created invoice items appearing first.
type InvoiceItemListParams struct {
	ListParams `form:"*"`
	// Only return invoice items that were created during the given date interval.
	Created *int64 `form:"created" json:"created,omitempty"`
	// Only return invoice items that were created during the given date interval.
	CreatedRange *RangeQueryParams `form:"created" json:"-"`
	// The identifier of the customer whose invoice items to return. If none is provided, returns all invoice items.
	Customer *string `form:"customer" json:"customer,omitempty"`
	// The identifier of the account representing the customer whose invoice items to return. If none is provided, returns all invoice items.
	CustomerAccount *string `form:"customer_account" json:"customer_account,omitempty"`
	// Specifies which fields in the response should be expanded.
	Expand []*string `form:"expand" json:"expand,omitempty"`
	// Only return invoice items belonging to this invoice. If none is provided, all invoice items will be returned. If specifying an invoice, no customer identifier is needed.
	Invoice *string `form:"invoice" json:"invoice,omitempty"`
	// Set to `true` to only show pending invoice items, which are not yet attached to any invoices. Set to `false` to only show invoice items already attached to invoices. If unspecified, no filter is applied.
	Pending *bool `form:"pending" json:"pending,omitempty"`
}

// AddExpand appends a new field to expand.
func (p *InvoiceItemListParams) AddExpand(f string) {
	p.Expand = append(p.Expand, &f)
}

// Deletes an invoice item, removing it from an invoice. Deleting invoice items is only possible when they're not attached to invoices, or if it's attached to a draft invoice.
type InvoiceItemDeleteParams struct {
	Params `form:"*"`
}

// Retrieves the invoice item with the given ID.
type InvoiceItemRetrieveParams struct {
	Params `form:"*"`
	// Specifies which fields in the response should be expanded.
	Expand []*string `form:"expand" json:"expand,omitempty"`
}

// AddExpand appends a new field to expand.
func (p *InvoiceItemRetrieveParams) AddExpand(f string) {
	p.Expand = append(p.Expand, &f)
}

// The coupons, promotion codes & existing discounts which apply to the invoice item or invoice line item. Item discounts are applied before invoice discounts. Pass an empty string to remove previously-defined discounts.
type InvoiceItemUpdateDiscountParams struct {
	// ID of the coupon to create a new discount for.
	Coupon *string `form:"coupon" json:"coupon,omitempty"`
	// ID of an existing discount on the object (or one of its ancestors) to reuse.
	Discount *string `form:"discount" json:"discount,omitempty"`
	// ID of the promotion code to create a new discount for.
	PromotionCode *string `form:"promotion_code" json:"promotion_code,omitempty"`
}

// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
type InvoiceItemUpdatePeriodParams struct {
	// The end of the period, which must be greater than or equal to the start. This value is inclusive.
	End *int64 `form:"end" json:"end"`
	// The start of the period. This value is inclusive.
	Start *int64 `form:"start" json:"start"`
}

// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
type InvoiceItemUpdatePriceDataParams struct {
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency *string `form:"currency" json:"currency"`
	// The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
	Product *string `form:"product" json:"product"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
	UnitAmount *int64 `form:"unit_amount" json:"unit_amount,omitempty"`
	// Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
	UnitAmountDecimal *float64 `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
}

// The pricing information for the invoice item.
type InvoiceItemUpdatePricingParams struct {
	// The ID of the price object.
	Price *string `form:"price" json:"price,omitempty"`
}

// Updates the amount or description of an invoice item on an upcoming invoice. Updating an invoice item is only possible before the invoice it's attached to is closed.
type InvoiceItemUpdateParams struct {
	Params `form:"*"`
	// The integer amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. If you want to apply a credit to the customer's account, pass a negative amount.
	Amount *int64 `form:"amount" json:"amount,omitempty"`
	// An arbitrary string which you can attach to the invoice item. The description is displayed in the invoice for easy tracking.
	Description *string `form:"description" json:"description,omitempty"`
	// Controls whether discounts apply to this invoice item. Defaults to false for prorations or negative invoice items, and true for all other invoice items. Cannot be set to true for prorations.
	Discountable *bool `form:"discountable" json:"discountable,omitempty"`
	// The coupons, promotion codes & existing discounts which apply to the invoice item or invoice line item. Item discounts are applied before invoice discounts. Pass an empty string to remove previously-defined discounts.
	Discounts []*InvoiceItemUpdateDiscountParams `form:"discounts" json:"discounts,omitempty"`
	// Specifies which fields in the response should be expanded.
	Expand []*string `form:"expand" json:"expand,omitempty"`
	// Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
	Metadata map[string]string `form:"metadata" json:"metadata,omitempty"`
	// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
	Period *InvoiceItemUpdatePeriodParams `form:"period" json:"period,omitempty"`
	// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
	PriceData *InvoiceItemUpdatePriceDataParams `form:"price_data" json:"price_data,omitempty"`
	// The pricing information for the invoice item.
	Pricing *InvoiceItemUpdatePricingParams `form:"pricing" json:"pricing,omitempty"`
	// Non-negative integer. The quantity of units for the invoice item. Use `quantity_decimal` instead to provide decimal precision. This field will be deprecated in favor of `quantity_decimal` in a future version.
	Quantity *int64 `form:"quantity" json:"quantity,omitempty"`
	// Non-negative decimal with at most 12 decimal places. The quantity of units for the line item.
	QuantityDecimal *float64 `form:"quantity_decimal,high_precision" json:"quantity_decimal,string,omitempty"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
	TaxCode *string `form:"tax_code" json:"tax_code,omitempty"`
	// The tax rates which apply to the invoice item. When set, the `default_tax_rates` on the invoice do not apply to this invoice item. Pass an empty string to remove previously-defined tax rates.
	TaxRates []*string `form:"tax_rates" json:"tax_rates,omitempty"`
	// The decimal unit amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. This `unit_amount_decimal` will be multiplied by the quantity to get the full amount. Passing in a negative `unit_amount_decimal` will reduce the `amount_due` on the invoice. Accepts at most 12 decimal places.
	UnitAmountDecimal *float64                            `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
	UnsetFields       []InvoiceItemUpdateParamsUnsetField `form:"-" json:"-"`
}

// InvoiceItemUpdateParamsUnsetField is the list of fields that can be cleared/unset on InvoiceItemUpdateParams.
type InvoiceItemUpdateParamsUnsetField string

const (
	InvoiceItemUpdateParamsUnsetFieldDiscounts InvoiceItemUpdateParamsUnsetField = "discounts"
	InvoiceItemUpdateParamsUnsetFieldMetadata  InvoiceItemUpdateParamsUnsetField = "metadata"
	InvoiceItemUpdateParamsUnsetFieldTaxCode   InvoiceItemUpdateParamsUnsetField = "tax_code"
	InvoiceItemUpdateParamsUnsetFieldTaxRates  InvoiceItemUpdateParamsUnsetField = "tax_rates"
)

// AddUnsetField adds a field to the list of fields to clear/unset on this params object.
func (p *InvoiceItemUpdateParams) AddUnsetField(field InvoiceItemUpdateParamsUnsetField) {
	p.UnsetFields = append(p.UnsetFields, field)
}

// AddExpand appends a new field to expand.
func (p *InvoiceItemUpdateParams) AddExpand(f string) {
	p.Expand = append(p.Expand, &f)
}

// AddMetadata adds a new key-value pair to the Metadata.
func (p *InvoiceItemUpdateParams) AddMetadata(key string, value string) {
	if p.Metadata == nil {
		p.Metadata = make(map[string]string)
	}

	p.Metadata[key] = value
}

// The coupons and promotion codes to redeem into discounts for the invoice item or invoice line item.
type InvoiceItemCreateDiscountParams struct {
	// ID of the coupon to create a new discount for.
	Coupon *string `form:"coupon" json:"coupon,omitempty"`
	// ID of an existing discount on the object (or one of its ancestors) to reuse.
	Discount *string `form:"discount" json:"discount,omitempty"`
	// ID of the promotion code to create a new discount for.
	PromotionCode *string `form:"promotion_code" json:"promotion_code,omitempty"`
}

// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
type InvoiceItemCreatePeriodParams struct {
	// The end of the period, which must be greater than or equal to the start. This value is inclusive.
	End *int64 `form:"end" json:"end"`
	// The start of the period. This value is inclusive.
	Start *int64 `form:"start" json:"start"`
}

// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
type InvoiceItemCreatePriceDataParams struct {
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency *string `form:"currency" json:"currency"`
	// The ID of the [Product](https://docs.stripe.com/api/products) that this [Price](https://docs.stripe.com/api/prices) will belong to.
	Product *string `form:"product" json:"product"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A positive integer in cents (or local equivalent) (or 0 for a free price) representing how much to charge.
	UnitAmount *int64 `form:"unit_amount" json:"unit_amount,omitempty"`
	// Same as `unit_amount`, but accepts a decimal value in cents (or local equivalent) with at most 12 decimal places. Only one of `unit_amount` and `unit_amount_decimal` can be set.
	UnitAmountDecimal *float64 `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
}

// The pricing information for the invoice item.
type InvoiceItemCreatePricingParams struct {
	// The ID of the price object.
	Price *string `form:"price" json:"price,omitempty"`
}

// Creates an item to be added to a draft invoice (up to 250 items per invoice). If no invoice is specified, the item will be on the next invoice created for the customer specified.
type InvoiceItemCreateParams struct {
	Params `form:"*"`
	// The integer amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. Passing in a negative `amount` will reduce the `amount_due` on the invoice.
	Amount *int64 `form:"amount" json:"amount,omitempty"`
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency *string `form:"currency" json:"currency,omitempty"`
	// The ID of the customer to bill for this invoice item.
	Customer *string `form:"customer" json:"customer,omitempty"`
	// The ID of the account representing the customer to bill for this invoice item.
	CustomerAccount *string `form:"customer_account" json:"customer_account,omitempty"`
	// An arbitrary string which you can attach to the invoice item. The description is displayed in the invoice for easy tracking.
	Description *string `form:"description" json:"description,omitempty"`
	// Controls whether discounts apply to this invoice item. Defaults to false for prorations or negative invoice items, and true for all other invoice items.
	Discountable *bool `form:"discountable" json:"discountable,omitempty"`
	// The coupons and promotion codes to redeem into discounts for the invoice item or invoice line item.
	Discounts []*InvoiceItemCreateDiscountParams `form:"discounts" json:"discounts,omitempty"`
	// Specifies which fields in the response should be expanded.
	Expand []*string `form:"expand" json:"expand,omitempty"`
	// The ID of an existing invoice to add this invoice item to. For subscription invoices, when left blank, the invoice item will be added to the next upcoming scheduled invoice. For standalone invoices, the invoice item won't be automatically added unless you pass `pending_invoice_item_behavior: 'include'` when creating the invoice. This is useful when adding invoice items in response to an invoice.created webhook. You can only add invoice items to draft invoices and there is a maximum of 250 items per invoice.
	Invoice *string `form:"invoice" json:"invoice,omitempty"`
	// Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format. Individual keys can be unset by posting an empty value to them. All keys can be unset by posting an empty value to `metadata`.
	Metadata map[string]string `form:"metadata" json:"metadata,omitempty"`
	// The period associated with this invoice item. When set to different values, the period will be rendered on the invoice. If you have [Stripe Revenue Recognition](https://docs.stripe.com/revenue-recognition) enabled, the period will be used to recognize and defer revenue. See the [Revenue Recognition documentation](https://docs.stripe.com/revenue-recognition/methodology/subscriptions-and-invoicing) for details.
	Period *InvoiceItemCreatePeriodParams `form:"period" json:"period,omitempty"`
	// Data used to generate a new [Price](https://docs.stripe.com/api/prices) object inline.
	PriceData *InvoiceItemCreatePriceDataParams `form:"price_data" json:"price_data,omitempty"`
	// The pricing information for the invoice item.
	Pricing *InvoiceItemCreatePricingParams `form:"pricing" json:"pricing,omitempty"`
	// Non-negative integer. The quantity of units for the invoice item. Use `quantity_decimal` instead to provide decimal precision. This field will be deprecated in favor of `quantity_decimal` in a future version.
	Quantity *int64 `form:"quantity" json:"quantity,omitempty"`
	// Non-negative decimal with at most 12 decimal places. The quantity of units for the invoice item.
	QuantityDecimal *float64 `form:"quantity_decimal,high_precision" json:"quantity_decimal,string,omitempty"`
	// The ID of a subscription to add this invoice item to. When left blank, the invoice item is added to the next upcoming scheduled invoice. When set, scheduled invoices for subscriptions other than the specified subscription will ignore the invoice item. Use this when you want to express that an invoice item has been accrued within the context of a particular subscription.
	Subscription *string `form:"subscription" json:"subscription,omitempty"`
	// Only required if a [default tax behavior](https://docs.stripe.com/tax/products-prices-tax-categories-tax-behavior#setting-a-default-tax-behavior-(recommended)) was not provided in the Stripe Tax settings. Specifies whether the price is considered inclusive of taxes or exclusive of taxes. One of `inclusive`, `exclusive`, or `unspecified`. Once specified as either `inclusive` or `exclusive`, it cannot be changed.
	TaxBehavior *string `form:"tax_behavior" json:"tax_behavior,omitempty"`
	// A [tax code](https://docs.stripe.com/tax/tax-categories) ID.
	TaxCode *string `form:"tax_code" json:"tax_code,omitempty"`
	// The tax rates which apply to the invoice item. When set, the `default_tax_rates` on the invoice do not apply to this invoice item.
	TaxRates []*string `form:"tax_rates" json:"tax_rates,omitempty"`
	// The decimal unit amount in cents (or local equivalent) of the charge to be applied to the upcoming invoice. This `unit_amount_decimal` will be multiplied by the quantity to get the full amount. Passing in a negative `unit_amount_decimal` will reduce the `amount_due` on the invoice. Accepts at most 12 decimal places.
	UnitAmountDecimal *float64                            `form:"unit_amount_decimal,high_precision" json:"unit_amount_decimal,string,omitempty"`
	UnsetFields       []InvoiceItemCreateParamsUnsetField `form:"-" json:"-"`
}

// InvoiceItemCreateParamsUnsetField is the list of fields that can be cleared/unset on InvoiceItemCreateParams.
type InvoiceItemCreateParamsUnsetField string

const (
	InvoiceItemCreateParamsUnsetFieldDiscounts InvoiceItemCreateParamsUnsetField = "discounts"
	InvoiceItemCreateParamsUnsetFieldMetadata  InvoiceItemCreateParamsUnsetField = "metadata"
	InvoiceItemCreateParamsUnsetFieldTaxCode   InvoiceItemCreateParamsUnsetField = "tax_code"
)

// AddUnsetField adds a field to the list of fields to clear/unset on this params object.
func (p *InvoiceItemCreateParams) AddUnsetField(field InvoiceItemCreateParamsUnsetField) {
	p.UnsetFields = append(p.UnsetFields, field)
}

// AddExpand appends a new field to expand.
func (p *InvoiceItemCreateParams) AddExpand(f string) {
	p.Expand = append(p.Expand, &f)
}

// AddMetadata adds a new key-value pair to the Metadata.
func (p *InvoiceItemCreateParams) AddMetadata(key string, value string) {
	if p.Metadata == nil {
		p.Metadata = make(map[string]string)
	}

	p.Metadata[key] = value
}

// Details about the subscription that generated this invoice item
type InvoiceItemParentSubscriptionDetails struct {
	// The subscription that generated this invoice item
	Subscription string `json:"subscription"`
	// The subscription item that generated this invoice item
	SubscriptionItem string `json:"subscription_item,omitempty"`
}

// The parent that generated this invoice item.
type InvoiceItemParent struct {
	// Details about the subscription that generated this invoice item
	SubscriptionDetails *InvoiceItemParentSubscriptionDetails `json:"subscription_details"`
	// The type of parent that generated this invoice item
	Type InvoiceItemParentType `json:"type"`
}
type InvoiceItemPricingPriceDetails struct {
	// The ID of the price this item is associated with.
	Price *Price `json:"price"`
	// The ID of the product this item is associated with.
	Product string `json:"product"`
}

// The pricing information of the invoice item.
type InvoiceItemPricing struct {
	PriceDetails *InvoiceItemPricingPriceDetails `json:"price_details,omitempty"`
	// The type of the pricing details.
	Type InvoiceItemPricingType `json:"type"`
	// The unit amount (in the `currency` specified) of the item which contains a decimal value with at most 12 decimal places.
	UnitAmountDecimal float64 `json:"unit_amount_decimal,string"`
}

// Discount amounts applied when the proration was created.
type InvoiceItemProrationDetailsDiscountAmount struct {
	// The amount, in cents (or local equivalent), of the discount.
	Amount int64 `json:"amount"`
	// The discount that was applied to get this discount amount.
	Discount *Discount `json:"discount"`
}
type InvoiceItemProrationDetails struct {
	// Discount amounts applied when the proration was created.
	DiscountAmounts []*InvoiceItemProrationDetailsDiscountAmount `json:"discount_amounts"`
}

// Invoice Items represent the component lines of an [invoice](https://docs.stripe.com/api/invoices). When you create an invoice item with an `invoice` field, it is attached to the specified invoice and included as [an invoice line item](https://docs.stripe.com/api/invoices/line_item) within [invoice.lines](https://docs.stripe.com/api/invoices/object#invoice_object-lines).
//
// Invoice Items can be created before you are ready to actually send the invoice. This can be particularly useful when combined
// with a [subscription](https://docs.stripe.com/api/subscriptions). Sometimes you want to add a charge or credit to a customer, but actually charge
// or credit the customer's card only at the end of a regular billing cycle. This is useful for combining several charges
// (to minimize per-transaction fees), or for having Stripe tabulate your usage-based billing totals.
//
// Related guides: [Integrate with the Invoicing API](https://docs.stripe.com/invoicing/integration), [Subscription Invoices](https://docs.stripe.com/billing/invoices/subscription#adding-upcoming-invoice-items).
type InvoiceItem struct {
	APIResource
	// Amount (in the `currency` specified) of the invoice item. This should always be equal to `unit_amount * quantity`.
	Amount int64 `json:"amount"`
	// Three-letter [ISO currency code](https://www.iso.org/iso-4217-currency-codes.html), in lowercase. Must be a [supported currency](https://stripe.com/docs/currencies).
	Currency Currency `json:"currency"`
	// The ID of the customer to bill for this invoice item.
	Customer *Customer `json:"customer"`
	// The ID of the account to bill for this invoice item.
	CustomerAccount string `json:"customer_account"`
	// Time at which the object was created. Measured in seconds since the Unix epoch.
	Date    int64 `json:"date"`
	Deleted bool  `json:"deleted,omitempty"`
	// An arbitrary string attached to the object. Often useful for displaying to users.
	Description string `json:"description"`
	// If true, discounts will apply to this invoice item. Always false for prorations.
	Discountable bool `json:"discountable"`
	// The discounts which apply to the invoice item. Item discounts are applied before invoice discounts. Use `expand[]=discounts` to expand each discount.
	Discounts []*Discount `json:"discounts"`
	// Unique identifier for the object.
	ID string `json:"id"`
	// The ID of the invoice this invoice item belongs to.
	Invoice *Invoice `json:"invoice"`
	// If the object exists in live mode, the value is `true`. If the object exists in test mode, the value is `false`.
	Livemode bool `json:"livemode"`
	// Set of [key-value pairs](https://docs.stripe.com/api/metadata) that you can attach to an object. This can be useful for storing additional information about the object in a structured format.
	Metadata map[string]string `json:"metadata"`
	// The amount after discounts, but before credits and taxes. This field is `null` for `discountable=true` items.
	NetAmount int64 `json:"net_amount,omitempty"`
	// String representing the object's type. Objects of the same type share the same value.
	Object string `json:"object"`
	// The parent that generated this invoice item.
	Parent *InvoiceItemParent `json:"parent"`
	Period *Period            `json:"period"`
	// The pricing information of the invoice item.
	Pricing *InvoiceItemPricing `json:"pricing"`
	// Whether the invoice item was created automatically as a proration adjustment when the customer switched plans.
	Proration        bool                         `json:"proration"`
	ProrationDetails *InvoiceItemProrationDetails `json:"proration_details,omitempty"`
	// Quantity of units for the invoice item in integer format, with any decimal precision truncated. For the item's full-precision decimal quantity, use `quantity_decimal`. This field will be deprecated in favor of `quantity_decimal` in a future version. If the invoice item is a proration, the quantity of the subscription that the proration was computed for.
	Quantity int64 `json:"quantity"`
	// Non-negative decimal with at most 12 decimal places. The quantity of units for the invoice item.
	QuantityDecimal float64 `json:"quantity_decimal,string"`
	// The tax rates which apply to the invoice item. When set, the `default_tax_rates` on the invoice do not apply to this invoice item.
	TaxRates []*TaxRate `json:"tax_rates"`
	// ID of the test clock this invoice item belongs to.
	TestClock *TestHelpersTestClock `json:"test_clock"`
}

// InvoiceItemList is a list of InvoiceItems as retrieved from a list endpoint.
type InvoiceItemList struct {
	APIResource
	ListMeta
	Data []*InvoiceItem `json:"data"`
}
