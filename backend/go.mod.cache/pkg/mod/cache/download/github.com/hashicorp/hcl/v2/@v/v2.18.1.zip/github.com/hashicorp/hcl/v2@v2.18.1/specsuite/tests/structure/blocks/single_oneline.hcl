a { b = "foo" }
