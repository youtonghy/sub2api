go test fuzz v1
[]byte("")