module github.com/imroc/req/v3

go 1.25.0

require (
	github.com/andybalholm/brotli v1.2.0
	github.com/google/go-querystring v1.1.0
	github.com/icholy/digest v1.1.0
	github.com/klauspost/compress v1.18.2
	github.com/quic-go/qpack v0.6.0
	github.com/quic-go/quic-go v0.60.0
	github.com/refraction-networking/utls v1.8.2
	golang.org/x/net v0.55.0
	golang.org/x/text v0.37.0
)

require (
	github.com/google/go-cmp v0.7.0 // indirect
	go.uber.org/mock v0.6.0 // indirect
	golang.org/x/crypto v0.51.0 // indirect
	golang.org/x/sys v0.45.0 // indirect
)
