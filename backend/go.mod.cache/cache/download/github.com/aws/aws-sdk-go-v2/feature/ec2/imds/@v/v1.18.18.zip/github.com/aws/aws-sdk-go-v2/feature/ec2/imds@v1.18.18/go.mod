module github.com/aws/aws-sdk-go-v2/feature/ec2/imds

go 1.23

require (
	github.com/aws/aws-sdk-go-v2 v1.41.2
	github.com/aws/smithy-go v1.24.1
)

replace github.com/aws/aws-sdk-go-v2 => ../../../
