// Package doc
package doc