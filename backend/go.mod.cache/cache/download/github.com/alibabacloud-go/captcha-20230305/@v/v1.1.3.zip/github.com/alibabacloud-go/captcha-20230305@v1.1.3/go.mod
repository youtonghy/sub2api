module github.com/alibabacloud-go/captcha-20230305

go 1.14

require (
	github.com/alibabacloud-go/darabonba-openapi/v2 v2.1.13
	github.com/alibabacloud-go/tea v1.3.13
)
